<div class="row">
    <div class="col-lg-12">
<h1 class="page-header">
 <?php
$suc = $this->session->userdata("success");
if ($suc != NULL) {
    echo "<p class='glyphicon glyphicon-ok-circle animated bounce' style='color:green;'> {$suc}</p>";
    $this->session->unset_userdata("success");
}
$err = $this->session->userdata("error");
if ($err != NULL) {
    echo "<p class='glyphicon glyphicon-ok-circle animated bounce' style='color:red;'> {$err}</p>";
    $this->session->unset_userdata("error");
}?>
</h1>
<p class="fa fa-plus-square"> Product</p>
  </div>
</div>
<div class="col-lg-4">    
<?php
echo validation_errors();
$this->load->helper("form");
$data = array("name" => "myform","enctype"=>"multipart/formdata");
echo form_open("product_management/insert",$data);
$data = array(
    "name" => "title",
    "id" => "id",
    "class" => "form-control",
    "value" => set_value("title"),
    "placeholder" => "Product Title"
);
echo form_input($data);
$data = array(
    "name" => "descr",
    "id" => "id",
    "class" => "form-control",
    "value" => set_value("form-control"),
    "placeholder" => "Product descr"
);
echo form_textarea($data);

$data = array(
    "name" => "price",
    "id" => "id",
    "class" => "form-control",
    "value" => set_value("price"),
    "placeholder" => "Product price"
);
echo form_input($data);

$data = array(
    "name" => "size",
    "id" => "id",
    "class" => "form-control",
    "value" => set_value("size"),
    "placeholder" => "Product size"
);
echo form_input($data);

/*$data = array();
    $data[0] = " Select catagory";
    foreach ( $allCat as $u){
        $data[$u->id]= $u -> name;
    }
echo form_dropdown("unitid",$data,4);*/





//echo form_label("<br />Product Price");
$data = array(
    "name" => "vat",
    "id" => "id",
    "class" => "form-control",
    "value" => set_value("vat"),
    "placeholder" => "Product vat"
);
echo form_input($data);

$data = array(
    "name" => "dis",
    "id" => "id",
    "class" => "form-control",
    "value" => set_value("dis"),
    "placeholder" => "Product discpunt"
);
echo form_input($data);
?>
 <div class="form-group">
       
    <select class="form-control" name="cat" onchange="CatScat(document.myform)">
                    <option value="0">Choose Category</option>
                    <?php
                        foreach ($allCat as $cat){
                            echo "<option value=\"{$cat->id}\">{$cat->name}</option>";    
                        }
                    ?>                    
</select>
</div>
    <div class="form-group">
 <select class="form-control" name="scat"></select>
</div>
    
    <?php
$data = array(
    "name" => "stock",
    "id" => "id",
    "class" => "form-control",
    "value" => set_value("stock"),
    "placeholder" => "Product stock"
);
echo form_input($data);

/*$data = array();
    $data[0] = " Select unit";
    foreach ( $allunit as $u){
        $data[$u->id]= $u -> name;
    }
echo form_dropdown("unitid",$data);*/
?>
<select class="form-control" name="unit" >
                    <option value="0">Choose unit</option>
                    <?php
                        foreach ($allunit as $cat){
                            echo "<option value=\"{$cat->id}\">{$cat->name}</option>";    
                        }
                    ?>                    
</select>

<?php 
$data = array(
    "name" => "sub",
    "id" => "id",
    "class" => "btn btn-default",
    "value" => "Save"
);
echo form_submit($data);
$data = array(
    'name' => 'button',
    'id' => 'button',
    'value' => 'true',
    'type' => 'reset',
    'content' => 'Reset'
);
?>
                
                
   <script type="text/javascript">
            function CatScat(data){
                data.scat.options.length = 0;
                var cid = data.cat.options[data.cat.selectedIndex].value;
                if(cid == 0){
                    data.scat.options[0] = new Option("Choose Category first", 0);
                }
                <?php
                    foreach ($allCat as $cat){
                        echo "else if(cid == {$cat->id}){";
                        foreach ($allSCat as $scat){
                            if($scat->categoryid == $cat->id){
                                echo "data.scat.options[data.scat.options.length] = new Option(\"{$scat->name}\", {$scat->id});";
                            }
                        }
                        echo "}";
                    }
                ?>
            }
        </script>
        
        
</div>

